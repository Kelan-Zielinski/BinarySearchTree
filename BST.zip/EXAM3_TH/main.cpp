#include "bst.cpp"
#include <iostream>
#include <fstream>

using namespace std;

int main(){
    BST meta;

    meta.saveTreeToFile("macbeth.txt", "paradiselost.txt", "metaphysics.txt", "tdata.txt", "out.txt");  
//  meta.loadTreeFromFile("out.txt","loadout.txt");  
//  meta.PrintInOrder();
//  meta.PrintPreOrder();
//  meta.PrintPostOrder();
    std::cout<<std::endl<<"Same value count: "<<sameValCount<<std::endl;
    std::cout<<"Node Count: "<<nodeCount<<std::endl<<std::endl;
    
    if (meta.isBalanced())
       std::cout << "Tree is balanced"<<endl<<std::endl;
    else
       std::cout << "Tree is not balanced"<<endl<<std::endl;
    
    return 0;
}