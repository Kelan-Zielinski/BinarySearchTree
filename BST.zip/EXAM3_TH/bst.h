#include <string>
#include <iostream>
#include <ostream>
#include <fstream>

class BST
{
    private:

    struct node{
        std::string key;        
        node *left;     
        node *right;        
    };
    
    node *root;
    
    void addLeafPrivate(std::string key, node* Ptr);        //method to add leaf to the tree once accessed the root pointer
    void PrintInOrderPrivate(node* Ptr);        //method to print the BST in order once accessed the root pointer
    void PrintPreOrderPrivate(node* Ptr);        //method to print the BST in pre order once accessed the root pointer
    void PrintPostOrderPrivate(node* Ptr);       //method to print the BST in post order once accessed the root pointer
    int isBalancedPrivate(node* root);      //method to calculate if the tree is balanced once accessed the root pointer
    int maxDepth(node* node);        //method to get the depth of the tree once accessed the root pointer
    void printToFile(node* Ptr, std::ofstream &outFile);        //method to print the read in data from file into the bst and to a out file
 public:
    BST();
    ~BST();
    node *CreateLeaf(std::string key);      //method to create first leaf of the tree when the root is null
    void addLeaf(std::string key);      //constructor to add leaf to the tree of new data(key)
    void PrintInOrder();        //method to print the BST in order
    void PrintPreOrder();       //method to print the BST in pre order
    void PrintPostOrder();      //method to print the BST in post order
    void getDepth();        //method to get the height of the trees
    int isBalanced();       //method to calculate if the tree is balanced
    void saveTreeToFile(std::string fileInput, std::string fileInput1, std::string fileInput2, std::string fileInput3, std::string fileOutput);     //method to read in files and perform the comaprisons
    void loadTreeFromFile(std::string fin, std::string fout);       //loads the tree from the created file in the printToFile
};
