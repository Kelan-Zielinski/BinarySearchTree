#include <iostream>
#include <fstream>
#include <string>
#include "bst.h"
#include <vector>
#include <algorithm>

using namespace std;

int sameValCount =0;
int nodeCount =0;

BST::BST(){
    root = NULL;
}

BST::~BST(){
    delete root;
}

BST::node* BST::CreateLeaf(std::string key){        //method to create first leaf of the tree when the root is null
    node* n = new node;     //create a new node and set both left and right sides of tree pointers to null
    n -> key = key;
    n -> left = NULL;       //set left to null
    n -> right = NULL;      //set right to null
    return n;}

    void BST::addLeaf(std::string key){     //constructor to add leaf to the tree of new data(key)
        addLeafPrivate(key, root);
    }

    void BST::addLeafPrivate(std::string key, node* Ptr){       //method to add leaf to the tree once accessed the root pointer
        if(root ==NULL){        //if the root is null then create new node which will be the root
            root = CreateLeaf(key);
        }
        // check if the data is greater or less than that of the previous node and place it in its correct position(either right or left)
        else if(key<Ptr->key){    
            if(Ptr->left !=NULL){
                addLeafPrivate(key, Ptr->left);
            }
            else {
                Ptr-> left = CreateLeaf(key);
            }
        }
          else if(key>Ptr->key){
            if(Ptr->right !=NULL){
                addLeafPrivate(key, Ptr->right);
            }
            else {
                Ptr-> right = CreateLeaf(key);
            }
        }
        else{       //when a value has already been added to the tree
            sameValCount++;
        }
    }

  void BST:: PrintInOrder(){        //method to print the BST in order
    PrintInOrderPrivate(root);}

  void BST:: PrintInOrderPrivate(node* Ptr){    //method to print the BST in order once accessed the root pointer
    if(root != NULL){
        if(Ptr->left !=NULL){
            PrintInOrderPrivate(Ptr->left);     //recurrsive call to the left side of the tree to print out all data
        }
        std::cout<<Ptr->key<<" ";
        if(Ptr->right != NULL){
            PrintInOrderPrivate(Ptr->right);        //recurrsive call to print out all value of the right side of the tree
        }
    }
    else{       //if the root is null then the tree is empty... nothing to print
        std::cout<<"The tree is empty"<<std::endl;
    }
  }


void BST::PrintPreOrder(){      //method to print the BST in pre order
    PrintPreOrderPrivate(root);  
}


void BST:: PrintPreOrderPrivate(node* Ptr){     //method to print the BST in pre order once accessed the root pointer
    if (Ptr == NULL)
        return;
    std:: cout << Ptr->key << " ";
    //recursively traversing left and right side of the tree to print the values
    PrintPreOrderPrivate(Ptr->left);        
    PrintPreOrderPrivate(Ptr->right);
} 

void BST::PrintPostOrder(){     //method to print the BST in post order
    PrintPostOrderPrivate(root);  
}   

void BST::PrintPostOrderPrivate(node* Ptr){     //method to print the BST in post order once accessed the root pointer
    if (Ptr == NULL)
        return;
 
    PrintPostOrderPrivate(Ptr->left);
    PrintPostOrderPrivate(Ptr->right);
    std::cout << Ptr->key << " ";
}   

void BST::getDepth(){       //method to get the height of the trees
    std::cout<<maxDepth(root);
}

   int BST::maxDepth(node* node)        //method to get the depth of the tree once accessed the root pointer
{
    if (node == NULL)
        return 0;
    else {
        int leftdepth = maxDepth(node->left);      //get the value of the height of the left side of the tree
        int rightdepth = maxDepth(node->right);     //get the value for the right side of the tree
        if (leftdepth > rightdepth)
            return (leftdepth + 1);
        else
            return (rightdepth + 1);
    }
}  

int BST::isBalanced(){      //method to calculate if the tree is balanced
    isBalancedPrivate(root);
return 0;
}

int BST::isBalancedPrivate(node* root){        //method to calculate if the tree is balanced once accessed the root pointer
    int leftheight =0;
    int rightheight =0;
    if (root == NULL)
        return 1;
    leftheight = maxDepth(root->left);      //calculate the left height of the tree
    rightheight = maxDepth(root->right);    //calculate the right height of the tree
 
    if (abs(leftheight - rightheight) <= 1 && isBalancedPrivate(root->left)&& isBalancedPrivate(root->right))
        return 1;       //if the difference between the heights of each side of the tree is greater than one it is not balanced
    return 0;
}
     
void BST::saveTreeToFile(std::string fileInput, std::string fileInput1, std::string fileInput2, std::string fileInput3, std::string fileOutput){        //method to read in files and perform the comaprisons
    BST meta;
    //open the files
    std::vector<std::string> wordsInFile;
    std::string word;
    std::fstream fin;
    fin.open(fileInput);
    std::fstream fin1;
    fin1.open(fileInput1);
    std::fstream fin2;
    fin2.open(fileInput2);
    std::fstream fin3;
    fin3.open(fileInput3);
    //read in the data
    while(fin>>word){
    for (int i = 0, length = word.size(); i < length; i++)        //for loop to remove all the punctuation
    {
     if(word[i]>='A' && word[i]<='Z'){        
            word[i]=((char)(word[i]-'A'+'a'));  
        }
        if (std::ispunct(word[i]))
        {
            word.erase(i--, 1);
            length = word.size();
        }
    }
//CODE FOR AMOUNT OF TIMES A WORD APPEARS
//  std::vector<std::string> wordsInFile;
    wordsInFile.push_back(word);            //add the word to the vector to compare

    meta.addLeaf(word);     //add the data to the tree
    nodeCount++;        //increment the amount of nodes added to the tree
}
//read in the second file
   while(fin1>>word){
    for (int i = 0, len = word.size(); i < len; i++)
    {
     if(word[i]>='A' && word[i]<='Z'){        
            word[i]=((char)(word[i]-'A'+'a'));  
        }
        if (std::ispunct(word[i]))
        {
            word.erase(i--, 1);
            len = word.size();
        }
    }
//CODE FOR AMOUNT OF TIMES A WORD APPEARS
//  std::vector<std::string> wordsInFile;
    wordsInFile.push_back(word);    
 
    meta.addLeaf(word);
    nodeCount++;
} 
   while(fin2>>word){
    for (int i = 0, len = word.size(); i < len; i++)
    {
     if(word[i]>='A' && word[i]<='Z'){        
            word[i]=((char)(word[i]-'A'+'a'));  
        }
        if (std::ispunct(word[i]))
        {
            word.erase(i--, 1);
            len = word.size();
        }
    }
//CODE FOR AMOUNT OF TIMES A WORD APPEARS
//  std::vector<std::string> wordsInFile;
    wordsInFile.push_back(word);    
 
    meta.addLeaf(word);
    nodeCount++;
} 
   while(fin3>>word){
    for (int i = 0, len = word.size(); i < len; i++)
    {
     if(word[i]>='A' && word[i]<='Z'){        
            word[i]=((char)(word[i]-'A'+'a'));  
        }
        if (std::ispunct(word[i]))
        {
            word.erase(i--, 1);
            len = word.size();
        }
    }
//CODE FOR AMOUNT OF TIMES A WORD APPEARS
//  std::vector<std::string> wordsInFile;
    wordsInFile.push_back(word);    
 
    meta.addLeaf(word);
    nodeCount++;
} 
    //sort the vector to calculate how many times nodes are repeated
    sort(wordsInFile.begin(), wordsInFile.end());
    int vec_size = wordsInFile.size();

    if(vec_size ==0) std::cout<<"No words in file"<<std::endl;
    
    int wordCount = 1;
    word = wordsInFile[0];
    //loop to print how many times a word is repeated in a file
    for(int i=1; i<vec_size; i++){
        if(word!= wordsInFile[i]){
            std::cout<<word<< ": "<<wordCount<<std::endl;
            wordCount =0;
            word = wordsInFile[i];
            }
        wordCount++;
    }
    std::cout<<word<< ": "<<wordCount<<std::endl;

    fin.close();
    fin1.close();
    fin2.close();
    fin3.close();
    std::ofstream outFile;
    outFile.open(fileOutput);
    meta.printToFile(meta.root, outFile);
    outFile.close();
    std::cout<<std::endl;
    std::cout<<"Depth: ";
    meta.getDepth();
}


void BST::printToFile(node* Ptr, std::ofstream &outFile){       //method to print the read in data from file into the bst and to a out file
        if (Ptr == NULL)
            return;
        else {
            outFile << Ptr->key <<std::endl;        
            printToFile(Ptr->left, outFile);        //recurrsively traverse the left side of the tree
            printToFile(Ptr->right, outFile);       //recurrsively traverse the right side of the tree 
        }
}

void BST::loadTreeFromFile(std::string fileInput, std::string fileOutput){      //loads the tree from the created file in the printToFile
 BST meta;
    std::string word;
    std::fstream fin;
    fin.open(fileInput);
    while(fin>>word){
    meta.addLeaf(word);}
    fin.close();
    std::ofstream outFile;
    outFile.open(fileOutput);
    meta.printToFile(meta.root, outFile);
    outFile.close();   
}

















